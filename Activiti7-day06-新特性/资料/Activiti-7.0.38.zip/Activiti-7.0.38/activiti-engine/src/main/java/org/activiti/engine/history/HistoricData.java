package org.activiti.engine.history;

import java.util.Date;

/**

 */
public interface HistoricData {

  Date getTime();

}
