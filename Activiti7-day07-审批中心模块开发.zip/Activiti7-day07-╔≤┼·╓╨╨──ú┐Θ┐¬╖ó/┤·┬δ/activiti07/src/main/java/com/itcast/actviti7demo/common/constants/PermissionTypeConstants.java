package com.itcast.actviti7demo.common.constants;

/**
 * Created with IDEA
 * Author:xzengsf
 * Date:2018/10/24 15:11
 * Description:
 */
public class PermissionTypeConstants {
    public static final int MENU=1;
    public static final int POINT=2;
    public static final int API=3;
}
