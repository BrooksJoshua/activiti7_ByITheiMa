package com.itcast.actviti7demo.service;

import com.itcast.actviti7demo.model.Holiday;

/**
 * Created by Administrator on 2019/5/1.
 */
public interface HolidayService {
    void saveHoliday(Holiday holiday);
}
