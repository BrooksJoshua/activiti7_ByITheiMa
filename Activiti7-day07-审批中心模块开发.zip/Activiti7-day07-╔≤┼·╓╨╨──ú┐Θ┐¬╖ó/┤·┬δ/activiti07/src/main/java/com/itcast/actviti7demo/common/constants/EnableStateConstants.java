package com.itcast.actviti7demo.common.constants;

/**
 * Created with IDEA
 * Author:xzengsf
 * Date:2018/10/24 15:11
 * Description:
 */
public class EnableStateConstants {
    public static final int DISABLE=0;
    public static final int ENABLE=1;
}
