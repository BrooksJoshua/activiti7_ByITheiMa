package com.itcast.actviti7demo.common.vo;

import com.itcast.actviti7demo.model.HolidayAudit;

import java.io.Serializable;

public class HolidayAuditCustom extends HolidayAudit implements Serializable{

	/** serialVersionUID*/
	private static final long serialVersionUID = 8665722908626307411L;

}
